import{s as V,R as ke,j as r,a as Ce,r as L}from"./storage-lQ0JPO6r.js";var _={};(function w(b,f,m,v){var C=!!(b.Worker&&b.Blob&&b.Promise&&b.OffscreenCanvas&&b.OffscreenCanvasRenderingContext2D&&b.HTMLCanvasElement&&b.HTMLCanvasElement.prototype.transferControlToOffscreen&&b.URL&&b.URL.createObjectURL),T=typeof Path2D=="function"&&typeof DOMMatrix=="function",W=(function(){if(!b.OffscreenCanvas)return!1;try{var t=new OffscreenCanvas(1,1),e=t.getContext("2d");e.fillRect(0,0,1,1);var a=t.transferToImageBitmap();e.createPattern(a,"no-repeat")}catch{return!1}return!0})();function A(){}function B(t){var e=f.exports.Promise,a=e!==void 0?e:b.Promise;return typeof a=="function"?new a(t):(t(A,A),null)}var E=(function(t,e){return{transform:function(a){if(t)return a;if(e.has(a))return e.get(a);var o=new OffscreenCanvas(a.width,a.height),i=o.getContext("2d");return i.drawImage(a,0,0),e.set(a,o),o},clear:function(){e.clear()}}})(W,new Map),O=(function(){var t=Math.floor(16.666666666666668),e,a,o={},i=0;return typeof requestAnimationFrame=="function"&&typeof cancelAnimationFrame=="function"?(e=function(s){var l=Math.random();return o[l]=requestAnimationFrame(function n(c){i===c||i+t-1<c?(i=c,delete o[l],s()):o[l]=requestAnimationFrame(n)}),l},a=function(s){o[s]&&cancelAnimationFrame(o[s])}):(e=function(s){return setTimeout(s,t)},a=function(s){return clearTimeout(s)}),{frame:e,cancel:a}})(),M=(function(){var t,e,a={};function o(i){function s(l,n){i.postMessage({options:l||{},callback:n})}i.init=function(n){var c=n.transferControlToOffscreen();i.postMessage({canvas:c},[c])},i.fire=function(n,c,h){if(e)return s(n,null),e;var g=Math.random().toString(36).slice(2);return e=B(function(u){function x(y){y.data.callback===g&&(delete a[g],i.removeEventListener("message",x),e=null,E.clear(),h(),u())}i.addEventListener("message",x),s(n,g),a[g]=x.bind(null,{data:{callback:g}})}),e},i.reset=function(){i.postMessage({reset:!0});for(var n in a)a[n](),delete a[n]}}return function(){if(t)return t;if(!m&&C){var i=["var CONFETTI, SIZE = {}, module = {};","("+w.toString()+")(this, module, true, SIZE);","onmessage = function(msg) {","  if (msg.data.options) {","    CONFETTI(msg.data.options).then(function () {","      if (msg.data.callback) {","        postMessage({ callback: msg.data.callback });","      }","    });","  } else if (msg.data.reset) {","    CONFETTI && CONFETTI.reset();","  } else if (msg.data.resize) {","    SIZE.width = msg.data.resize.width;","    SIZE.height = msg.data.resize.height;","  } else if (msg.data.canvas) {","    SIZE.width = msg.data.canvas.width;","    SIZE.height = msg.data.canvas.height;","    CONFETTI = module.exports.create(msg.data.canvas);","  }","}"].join(`
`);try{t=new Worker(URL.createObjectURL(new Blob([i])))}catch(s){return typeof console<"u"&&typeof console.warn=="function"&&console.warn("🎊 Could not load worker",s),null}o(t)}return t}})(),R={particleCount:50,angle:90,spread:45,startVelocity:45,decay:.9,gravity:1,drift:0,ticks:200,x:.5,y:.5,shapes:["square","circle"],zIndex:100,colors:["#26ccff","#a25afd","#ff5e7e","#88ff5a","#fcff42","#ffa62d","#ff36ff"],disableForReducedMotion:!1,scalar:1};function S(t,e){return e?e(t):t}function k(t){return t!=null}function p(t,e,a){return S(t&&k(t[e])?t[e]:R[e],a)}function te(t){return t<0?0:Math.floor(t)}function re(t,e){return Math.floor(Math.random()*(e-t))+t}function U(t){return parseInt(t,16)}function ae(t){return t.map(ne)}function ne(t){var e=String(t).replace(/[^0-9a-f]/gi,"");return e.length<6&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),{r:U(e.substring(0,2)),g:U(e.substring(2,4)),b:U(e.substring(4,6))}}function oe(t){var e=p(t,"origin",Object);return e.x=p(e,"x",Number),e.y=p(e,"y",Number),e}function ie(t){t.width=document.documentElement.clientWidth,t.height=document.documentElement.clientHeight}function se(t){var e=t.getBoundingClientRect();t.width=e.width,t.height=e.height}function le(t){var e=document.createElement("canvas");return e.style.position="fixed",e.style.top="0px",e.style.left="0px",e.style.pointerEvents="none",e.style.zIndex=t,e}function ce(t,e,a,o,i,s,l,n,c){t.save(),t.translate(e,a),t.rotate(s),t.scale(o,i),t.arc(0,0,1,l,n,c),t.restore()}function de(t){var e=t.angle*(Math.PI/180),a=t.spread*(Math.PI/180);return{x:t.x,y:t.y,wobble:Math.random()*10,wobbleSpeed:Math.min(.11,Math.random()*.1+.05),velocity:t.startVelocity*.5+Math.random()*t.startVelocity,angle2D:-e+(.5*a-Math.random()*a),tiltAngle:(Math.random()*(.75-.25)+.25)*Math.PI,color:t.color,shape:t.shape,tick:0,totalTicks:t.ticks,decay:t.decay,drift:t.drift,random:Math.random()+2,tiltSin:0,tiltCos:0,wobbleX:0,wobbleY:0,gravity:t.gravity*3,ovalScalar:.6,scalar:t.scalar,flat:t.flat}}function he(t,e){e.x+=Math.cos(e.angle2D)*e.velocity+e.drift,e.y+=Math.sin(e.angle2D)*e.velocity+e.gravity,e.velocity*=e.decay,e.flat?(e.wobble=0,e.wobbleX=e.x+10*e.scalar,e.wobbleY=e.y+10*e.scalar,e.tiltSin=0,e.tiltCos=0,e.random=1):(e.wobble+=e.wobbleSpeed,e.wobbleX=e.x+10*e.scalar*Math.cos(e.wobble),e.wobbleY=e.y+10*e.scalar*Math.sin(e.wobble),e.tiltAngle+=.1,e.tiltSin=Math.sin(e.tiltAngle),e.tiltCos=Math.cos(e.tiltAngle),e.random=Math.random()+2);var a=e.tick++/e.totalTicks,o=e.x+e.random*e.tiltCos,i=e.y+e.random*e.tiltSin,s=e.wobbleX+e.random*e.tiltCos,l=e.wobbleY+e.random*e.tiltSin;if(t.fillStyle="rgba("+e.color.r+", "+e.color.g+", "+e.color.b+", "+(1-a)+")",t.beginPath(),T&&e.shape.type==="path"&&typeof e.shape.path=="string"&&Array.isArray(e.shape.matrix))t.fill(fe(e.shape.path,e.shape.matrix,e.x,e.y,Math.abs(s-o)*.1,Math.abs(l-i)*.1,Math.PI/10*e.wobble));else if(e.shape.type==="bitmap"){var n=Math.PI/10*e.wobble,c=Math.abs(s-o)*.1,h=Math.abs(l-i)*.1,g=e.shape.bitmap.width*e.scalar,u=e.shape.bitmap.height*e.scalar,x=new DOMMatrix([Math.cos(n)*c,Math.sin(n)*c,-Math.sin(n)*h,Math.cos(n)*h,e.x,e.y]);x.multiplySelf(new DOMMatrix(e.shape.matrix));var y=t.createPattern(E.transform(e.shape.bitmap),"no-repeat");y.setTransform(x),t.globalAlpha=1-a,t.fillStyle=y,t.fillRect(e.x-g/2,e.y-u/2,g,u),t.globalAlpha=1}else if(e.shape==="circle")t.ellipse?t.ellipse(e.x,e.y,Math.abs(s-o)*e.ovalScalar,Math.abs(l-i)*e.ovalScalar,Math.PI/10*e.wobble,0,2*Math.PI):ce(t,e.x,e.y,Math.abs(s-o)*e.ovalScalar,Math.abs(l-i)*e.ovalScalar,Math.PI/10*e.wobble,0,2*Math.PI);else if(e.shape==="star")for(var d=Math.PI/2*3,j=4*e.scalar,F=8*e.scalar,N=e.x,P=e.y,z=5,I=Math.PI/z;z--;)N=e.x+Math.cos(d)*F,P=e.y+Math.sin(d)*F,t.lineTo(N,P),d+=I,N=e.x+Math.cos(d)*j,P=e.y+Math.sin(d)*j,t.lineTo(N,P),d+=I;else t.moveTo(Math.floor(e.x),Math.floor(e.y)),t.lineTo(Math.floor(e.wobbleX),Math.floor(i)),t.lineTo(Math.floor(s),Math.floor(l)),t.lineTo(Math.floor(o),Math.floor(e.wobbleY));return t.closePath(),t.fill(),e.tick<e.totalTicks}function ue(t,e,a,o,i){var s=e.slice(),l=t.getContext("2d"),n,c,h=B(function(g){function u(){n=c=null,l.clearRect(0,0,o.width,o.height),E.clear(),i(),g()}function x(){m&&!(o.width===v.width&&o.height===v.height)&&(o.width=t.width=v.width,o.height=t.height=v.height),!o.width&&!o.height&&(a(t),o.width=t.width,o.height=t.height),l.clearRect(0,0,o.width,o.height),s=s.filter(function(y){return he(l,y)}),s.length?n=O.frame(x):u()}n=O.frame(x),c=u});return{addFettis:function(g){return s=s.concat(g),h},canvas:t,promise:h,reset:function(){n&&O.cancel(n),c&&c()}}}function q(t,e){var a=!t,o=!!p(e||{},"resize"),i=!1,s=p(e,"disableForReducedMotion",Boolean),l=C&&!!p(e||{},"useWorker"),n=l?M():null,c=a?ie:se,h=t&&n?!!t.__confetti_initialized:!1,g=typeof matchMedia=="function"&&matchMedia("(prefers-reduced-motion)").matches,u;function x(d,j,F){for(var N=p(d,"particleCount",te),P=p(d,"angle",Number),z=p(d,"spread",Number),I=p(d,"startVelocity",Number),ge=p(d,"decay",Number),xe=p(d,"gravity",Number),be=p(d,"drift",Number),G=p(d,"colors",ae),ve=p(d,"ticks",Number),Z=p(d,"shapes"),ye=p(d,"scalar"),we=!!p(d,"flat"),Q=oe(d),K=N,H=[],Me=t.width*Q.x,je=t.height*Q.y;K--;)H.push(de({x:Me,y:je,angle:P,spread:z,startVelocity:I,color:G[K%G.length],shape:Z[re(0,Z.length)],ticks:ve,decay:ge,gravity:xe,drift:be,scalar:ye,flat:we}));return u?u.addFettis(H):(u=ue(t,H,c,j,F),u.promise)}function y(d){var j=s||p(d,"disableForReducedMotion",Boolean),F=p(d,"zIndex",Number);if(j&&g)return B(function(I){I()});a&&u?t=u.canvas:a&&!t&&(t=le(F),document.body.appendChild(t)),o&&!h&&c(t);var N={width:t.width,height:t.height};n&&!h&&n.init(t),h=!0,n&&(t.__confetti_initialized=!0);function P(){if(n){var I={getBoundingClientRect:function(){if(!a)return t.getBoundingClientRect()}};c(I),n.postMessage({resize:{width:I.width,height:I.height}});return}N.width=N.height=null}function z(){u=null,o&&(i=!1,b.removeEventListener("resize",P)),a&&t&&(document.body.contains(t)&&document.body.removeChild(t),t=null,h=!1)}return o&&!i&&(i=!0,b.addEventListener("resize",P,!1)),n?n.fire(d,N,z):x(d,N,z)}return y.reset=function(){n&&n.reset(),u&&u.reset()},y}var Y;function $(){return Y||(Y=q(null,{useWorker:!0,resize:!0})),Y}function fe(t,e,a,o,i,s,l){var n=new Path2D(t),c=new Path2D;c.addPath(n,new DOMMatrix(e));var h=new Path2D;return h.addPath(c,new DOMMatrix([Math.cos(l)*i,Math.sin(l)*i,-Math.sin(l)*s,Math.cos(l)*s,a,o])),h}function me(t){if(!T)throw new Error("path confetti are not supported in this browser");var e,a;typeof t=="string"?e=t:(e=t.path,a=t.matrix);var o=new Path2D(e),i=document.createElement("canvas"),s=i.getContext("2d");if(!a){for(var l=1e3,n=l,c=l,h=0,g=0,u,x,y=0;y<l;y+=2)for(var d=0;d<l;d+=2)s.isPointInPath(o,y,d,"nonzero")&&(n=Math.min(n,y),c=Math.min(c,d),h=Math.max(h,y),g=Math.max(g,d));u=h-n,x=g-c;var j=10,F=Math.min(j/u,j/x);a=[F,0,0,F,-Math.round(u/2+n)*F,-Math.round(x/2+c)*F]}return{type:"path",path:e,matrix:a}}function pe(t){var e,a=1,o="#000000",i='"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif';typeof t=="string"?e=t:(e=t.text,a="scalar"in t?t.scalar:a,i="fontFamily"in t?t.fontFamily:i,o="color"in t?t.color:o);var s=10*a,l=""+s+"px "+i,n=new OffscreenCanvas(s,s),c=n.getContext("2d");c.font=l;var h=c.measureText(e),g=Math.ceil(h.actualBoundingBoxRight+h.actualBoundingBoxLeft),u=Math.ceil(h.actualBoundingBoxAscent+h.actualBoundingBoxDescent),x=2,y=h.actualBoundingBoxLeft+x,d=h.actualBoundingBoxAscent+x;g+=x+x,u+=x+x,n=new OffscreenCanvas(g,u),c=n.getContext("2d"),c.font=l,c.fillStyle=o,c.fillText(e,y,d);var j=1/a;return{type:"bitmap",bitmap:n.transferToImageBitmap(),matrix:[j,0,0,j,-g*j/2,-u*j/2]}}f.exports=function(){return $().apply(this,arguments)},f.exports.reset=function(){$().reset()},f.exports.create=q,f.exports.shapeFromPath=me,f.exports.shapeFromText=pe})((function(){return typeof window<"u"?window:typeof self<"u"?self:this||{}})(),_,!1);const Fe=_.exports;_.exports.create;const Ne=["/checkout","/cart","/basket","/place-order","/payment","/pay","/buy","/purchase","shipping","billing","review","transaction","amazon.com/gp/buy","shopify.com/checkouts","paypal.com/webapps","wsCP"];function J(){const w=window.location.href.toLowerCase();if(Ne.some(m=>w.includes(m)))return!0;const f=document.title.toLowerCase();return!!(f.includes("checkout")||f.includes("payment method"))}const Ae=`
    @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap');

    .overlay-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(255, 253, 247, 0.95);
        backdrop-filter: blur(20px);
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Nunito', sans-serif;
        color: #1e293b;
    }

    .card {
        background: white;
        width: 500px;
        max-width: 90vw;
        padding: 48px;
        border-radius: 40px;
        text-align: center;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
        position: relative;
        animation: zoomIn 0.3s ease-out;
    }

    /* Gauntlet Specific Styles */
    .gauntlet-card {
        background: #FFF0F5;
        width: 600px;
        padding: 40px;
        border-radius: 32px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.1);
        text-align: left;
    }

    .progress-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 32px;
    }

    .heart-row {
        display: flex;
        gap: 4px;
    }

    .heart-icon {
        width: 16px;
        height: 16px;
        color: #e2e8f0;
        transition: color 0.3s;
    }
    .heart-icon.active {
        color: #FDA4AF;
        fill: #FDA4AF;
    }

    .question-text {
        font-size: 24px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 24px;
        line-height: 1.3;
    }

    .options-stack {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .option-btn {
        width: 100%;
        padding: 16px 20px;
        background: white;
        border-radius: 16px;
        border: none;
        text-align: left;
        font-family: inherit;
        font-size: 16px;
        color: #1e293b;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .option-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .grid-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .halt-btn {
        padding: 24px;
        background: white;
        border: 2px solid #e2e8f0;
        border-radius: 24px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s;
        font-family: inherit;
    }
    .halt-btn:hover {
        border-color: rgba(253, 164, 175, 0.5);
    }
    .halt-btn.selected {
        border-color: #FDA4AF;
        background-color: white;
    }

    .halt-emoji { font-size: 48px; margin-bottom: 8px; display: block; }
    .halt-label { font-size: 16px; color: #1e293b; font-weight: 600; }

    /* Animations */
    @keyframes zoomIn {
        from { transform: scale(0.95); opacity: 0; }
        to { transform: scale(1); opacity: 1; }
    }

    .close-btn {
        position: absolute;
        top: 24px;
        right: 24px;
        background: none;
        border: none;
        cursor: pointer;
        color: #cbd5e1;
        transition: color 0.2s;
    }
    .close-btn:hover { color: #64748b; }

    .icon-circle {
        width: 96px;
        height: 96px;
        background-color: #FFF0F5;
        border-radius: 50%;
        margin: 0 auto 24px auto;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .icon-svg {
        width: 48px;
        height: 48px;
        color: #FF8FAB;
    }

    h2 {
        font-size: 28px;
        font-weight: 800;
        margin: 0 0 32px 0;
        color: #1e293b;
        letter-spacing: -0.02em;
    }

    .timer-box {
        background-color: #FFF5F9;
        border-radius: 24px;
        padding: 32px;
        margin-bottom: 32px;
    }

    .timer-label {
        color: #94a3b8;
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        margin-bottom: 8px;
    }

    .timer-digits {
        color: #FF8FAB;
        font-size: 56px;
        font-weight: 600;
        line-height: 1;
        font-feature-settings: "tnum";
        font-variant-numeric: tabular-nums;
    }

    p {
        font-size: 18px;
        line-height: 1.6;
        color: #475569;
        margin: 0 0 32px 0;
    }

    .btn-primary {
        width: 100%;
        background-color: #FF8FAB;
        color: white;
        font-family: inherit;
        font-size: 18px;
        font-weight: 700;
        padding: 18px;
        border: none;
        border-radius: 99px;
        cursor: pointer;
        box-shadow: 0 10px 25px -5px rgba(255, 143, 171, 0.4);
        transition: transform 0.1s, background-color 0.2s;
        margin-bottom: 16px;
    }

    .btn-primary:hover {
        background-color: #ff7aa2;
        transform: scale(1.02);
    }
    .btn-primary:active {
        transform: scale(0.98);
    }

    .btn-secondary {
        background: none;
        border: none;
        font-family: inherit;
        font-size: 14px;
        color: #94a3b8;
        cursor: pointer;
        text-decoration: underline;
        text-decoration-color: transparent;
        transition: text-decoration-color 0.2s, color 0.2s;
    }
    .btn-secondary:hover {
        color: #64748b;
        text-decoration-color: #64748b;
    }
`,D=[{id:1,text:"Is this for a hobby you started less than 48 hours ago?",leftAnswer:"Yes, caught me 🙈",rightAnswer:"No, I'm serious"},{id:2,text:"Will you still want this in a week?",leftAnswer:"Probably not 😅",rightAnswer:"Yes, definitely"},{id:3,text:"Have you checked if you already own something similar?",leftAnswer:"Um... no",rightAnswer:"Yes, I checked"},{id:4,text:"Are you...",isHaltScreen:!0},{id:5,text:"Is this within your budget for this month?",leftAnswer:"Not really 💸",rightAnswer:"Yes, it fits"},{id:6,text:"Have you compared prices from at least 2 other places?",leftAnswer:"No, just here",rightAnswer:"Yes, this is best"},{id:7,text:"Will this solve a real problem you have RIGHT NOW?",leftAnswer:"It's more of a want",rightAnswer:"Yes, I need it"},{id:8,text:"Are you buying this to feel better emotionally?",leftAnswer:"Maybe yeah 🥺",rightAnswer:"No, it's practical"},{id:9,text:"If this was double the price, would you still buy it?",leftAnswer:"No way",rightAnswer:"Yes, still worth it"},{id:10,text:"Can you wait 24 more hours before deciding?",leftAnswer:"I guess I can wait",rightAnswer:"I really can't wait"}],Se=[{emoji:"🍔",label:"Hungry",id:"hungry"},{emoji:"😠",label:"Angry",id:"angry"},{emoji:"🥺",label:"Lonely",id:"lonely"},{emoji:"😴",label:"Tired",id:"tired"},{emoji:"✨",label:"None",id:"none"}];function Ie(){const w=["#sc-subtotal-amount-activecart","#subtotals-marketplace-table .grand-total-price",".grand-total-price","td.grand-total-price",".order-summary-grand-total","#subtotals .a-color-price"];for(const m of w){const v=document.querySelector(m);if(v&&v.textContent){const C=v.textContent.match(/[\d,]+\.\d{2}/);if(C)return parseFloat(C[0].replace(/,/g,""))}}const f=document.evaluate("//*[contains(text(), 'Total') or contains(text(), 'Order Total')]/following-sibling::*//text()[contains(., '$')] | //*[contains(text(), 'Total') or contains(text(), 'Order Total')]/..//*[contains(text(), '$')]",document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null);if(f.singleNodeValue&&f.singleNodeValue.textContent){const m=f.singleNodeValue.textContent.match(/[\d,]+\.\d{2}/);if(m)return parseFloat(m[0].replace(/,/g,""))}return 0}const Te=({active:w})=>r.jsx("svg",{className:`heart-icon ${w?"active":""}`,viewBox:"0 0 24 24",fill:"currentColor",stroke:"currentColor",strokeWidth:"2",children:r.jsx("path",{d:"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5 0 0 0 0-7.78z"})}),Pe=({onClose:w,onPass:b,savedAmount:f})=>{const[m,v]=L.useState(0),[C,T]=L.useState(!1),[W,A]=L.useState(null),[B,E]=L.useState(!1),O=()=>{T(!0),setTimeout(()=>E(!0),1500)},M=()=>{m<D.length-1?v(m+1):(Fe({particleCount:100,spread:70,origin:{y:.6},colors:["#FDA4AF","#93C5FD","#C4B5FD","#F472B6"]}),setTimeout(()=>{b()},2e3))},R=k=>{A(k),k==="none"?m<D.length-1&&(v(m+1),A(null)):(T(!0),setTimeout(()=>E(!0),2e3))},S=D[m];return B?r.jsxs("div",{className:"card",children:[r.jsx("style",{children:`
                    @keyframes float { 0% { transform: translateY(0px); } 50% { transform: translateY(-10px); } 100% { transform: translateY(0px); } }
                    .floating-gem { animation: float 3s ease-in-out infinite; font-size: 64px; display: block; margin-bottom: 24px; }
                `}),r.jsx("div",{className:"floating-gem",children:"💎"}),r.jsx("h2",{children:"Impulse Controlled!"}),r.jsxs("div",{className:"timer-box",children:[r.jsx("div",{className:"timer-label",children:"Money Saved"}),r.jsxs("div",{className:"timer-digits",children:["$",f>0?f.toFixed(2):"50.00+"]})]}),r.jsx("p",{children:"You earned 50 XP and saved your wallet. Proud of you."}),r.jsx("button",{onClick:w,className:"btn-primary",children:"Back to Safety"})]}):C?r.jsxs("div",{className:"card",children:[r.jsx("div",{style:{fontSize:"64px",marginBottom:"16px"},children:"💖"}),r.jsx("h2",{children:"That's okay, bestie!"}),r.jsx("p",{children:"The 48-hour timer is still running. We'll be here when you're ready."})]}):r.jsxs("div",{className:"gauntlet-card overlay-container",style:{position:"relative",background:"#FFF0F5",width:"600px",height:"auto",display:"block"},children:[r.jsxs("div",{className:"progress-header",children:[r.jsxs("span",{style:{fontSize:"14px",color:"#64748b"},children:["Question ",m+1," of ",D.length]}),r.jsx("div",{className:"heart-row",children:D.map((k,p)=>r.jsx(Te,{active:p<=m},p))})]}),r.jsx("div",{className:"question-text",children:S.text}),S.isHaltScreen?r.jsx("div",{className:"grid-2",children:Se.map(k=>r.jsxs("button",{onClick:()=>R(k.id),className:`halt-btn ${W===k.id?"selected":""}`,children:[r.jsx("span",{className:"halt-emoji",children:k.emoji}),r.jsx("span",{className:"halt-label",children:k.label})]},k.id))}):r.jsxs("div",{className:"options-stack",children:[r.jsx("button",{onClick:O,className:"option-btn",children:S.leftAnswer}),r.jsx("button",{onClick:M,className:"option-btn",children:S.rightAnswer})]})]})},Ee=({onClose:w})=>{const[b,f]=L.useState(172800),[m,v]=L.useState("timer"),[C,T]=L.useState(0);L.useEffect(()=>{const M=Ie();M>0&&T(M);const R=setInterval(()=>{f(S=>Math.max(0,S-1))},1e3);return()=>clearInterval(R)},[]);const W=M=>{const R=Math.floor(M/3600),S=Math.floor(M%3600/60),k=M%60;return`${R.toString().padStart(2,"0")}:${S.toString().padStart(2,"0")}:${k.toString().padStart(2,"0")}`},A=async()=>{await V.startCoolDown(window.location.href,C);try{chrome.runtime.sendMessage({action:"open_dashboard"})}catch(M){console.error("Failed to open dashboard",M)}w();try{chrome.runtime.sendMessage({action:"close_tab"})}catch(M){console.error("Failed to close tab",M)}},B=()=>{v("gauntlet")},E=async()=>{v("success")},O=async()=>{await V.allowBypass(window.location.href),w()};return r.jsxs("div",{className:"overlay-container",children:[r.jsx("div",{style:{position:"absolute",inset:0},onClick:A}),m==="success"&&r.jsxs("div",{className:"card",children:[r.jsx("div",{style:{color:"#FDA4AF",marginBottom:"16px"},children:r.jsx("svg",{width:"64",height:"64",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:r.jsx("path",{d:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"})})}),r.jsx("h2",{children:"You passed! ✨"}),r.jsx("p",{children:"Okay bestie, you've thought this through. Checkout unlocked!"}),r.jsx("button",{onClick:O,className:"btn-primary",children:"Proceed to Checkout"})]}),m==="gauntlet"&&r.jsx(Pe,{onClose:A,onPass:E,savedAmount:C}),m==="timer"&&r.jsxs("div",{className:"card",children:[r.jsx("button",{onClick:A,className:"close-btn",children:r.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[r.jsx("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),r.jsx("line",{x1:"6",y1:"6",x2:"18",y2:"18"})]})}),r.jsx("div",{className:"icon-circle",children:r.jsxs("svg",{className:"icon-svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[r.jsx("path",{d:"M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"}),r.jsx("path",{d:"M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2"}),r.jsx("path",{d:"M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8"}),r.jsx("path",{d:"M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"})]})}),r.jsx("h2",{children:"Whoa there, Bestie! Let's pause."}),r.jsxs("div",{className:"timer-box",children:[r.jsx("div",{className:"timer-label",children:"Cooling Off Period"}),r.jsx("div",{className:"timer-digits",children:W(b)})]}),r.jsxs("p",{children:["The 'Vibe Check' protocol is active. You can buy this... but not right now. Let's wait 48 hours to see if it's true love or just a dopamine hit.",r.jsx("span",{style:{display:"inline-block",marginLeft:"6px"},children:"✨"})]}),r.jsx("button",{onClick:A,className:"btn-primary",children:"Okay, I'll wait (Close Tab)"}),r.jsx("button",{onClick:B,className:"btn-secondary",children:"No, I actually need this for an emergency."})]})]})};async function ee(){if(document.getElementById("wallet-glow-root"))return;if(await V.isWhitelisted(window.location.href)){console.log("WalletGlow: URL is whitelisted. Shields Down.");return}console.log("WalletGlow: Impulse Detected. Engaging Shields."),document.querySelectorAll("video, audio").forEach(T=>T.pause());const f=document.createElement("div");f.id="wallet-glow-root",document.body.appendChild(f);const m=f.attachShadow({mode:"open"}),v=ke.createRoot(m),C=()=>{v.unmount(),f.remove(),document.body.style.overflow=""};v.render(r.jsxs(Ce.StrictMode,{children:[r.jsx("style",{children:Ae}),r.jsx(Ee,{onClose:C})]})),document.body.style.overflow="hidden"}let X=location.href;setInterval(()=>{const w=location.href;if(w!==X){if(X=w,window.location.protocol==="chrome-extension:")return;J()&&ee()}},1e3);J()&&ee();
